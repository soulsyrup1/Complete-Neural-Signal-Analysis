# Neuro Signal Importer + NeuroMouse Workbench

**Version:** `0.10.2-zip-archive-mat-support`  
**Purpose:** Convert, standardize, analyze, replay, and visualize continuous neural signal data from many file formats using a local Python backend and an HTML/NeuroMouse browser workbench.

This project is designed for **continuous neural signal data**: EEG, ECoG, iEEG, MEA, organoid recordings, FinalSpark-style data, Cortical Labs-style data, HDF5/NWB-style recordings, MATLAB structures, NumPy arrays, tabular exports, and related neurophysiology signal files.

It deliberately does **not** center the pipeline on spike tables, stimulation events, or fixed EEG-only assumptions. The main data model is:

```text
samples × channels continuous signal
+ channel/electrode metadata
+ sampling/time metadata
+ quality/provenance reports
+ optional offline/live/comparative analysis
```

---

### v0.10.2 ZIP archive + BCI Competition MAT support

The uploader can now accept `.zip` archives containing primary neural files such as `.mat`, `.edf`, `.set`, `.vhdr`, `.h5`, `.nwb`, `.npy`, or `.csv`. Archives are safely extracted inside the upload workspace, primary files are discovered inside the archive, and each discovered recording is converted normally. This specifically supports BCI Competition-style archives such as `BCICIV_1_mat.zip`, which contain multiple MATLAB `.mat` recordings with `cnt` signal arrays and `nfo` metadata.

### v0.10.1 NeuroMouse generated-data binding

Normal conversion jobs now also try to build a NeuroMouse-compatible `data.json` from the converted `signal.npy`. The Results tab can open `/neuromouse-job/<job_id>/`, which is hard-bound to `/api/jobs/<job_id>/neuromouse/data.json`. This prevents the integrated workbench from silently loading `/neuromouse/data/data.json`, the bundled demo dataset, when the user expects uploaded/converted data.

## Current System Overview

The system now has four major layers:

```text
1. Conversion backend
   raw neural file/folder → canonical converted recording

2. Offline analysis backend
   converted recording → features, summaries, NeuroMouse-compatible data.json

3. Live replay backend
   converted signal.npy → prerecorded live stream + raw/spectral WebSocket views

4. HTML frontend + original NeuroMouse workbench
   drag/drop, convert, analyze, compare, live replay, interactive visualization

5. Raw backend job logging
   saved job_log.txt + job_log.jsonl for each conversion/analysis/replay job
```

The two main browser pages are:

```text
http://127.0.0.1:8787/             Neuro Signal launcher/frontend
http://127.0.0.1:8787/neuromouse/  Original NeuroMouse workbench, integrated
```

The launcher page is our control center. NeuroMouse is the interactive neural signal visualization and comparison workbench.

---

## Important Design Boundary

This project is currently focused on:

- raw/continuous neural signals
- variable channel/electrode counts
- variable channel/electrode names
- batch conversion
- offline feature extraction
- live replay from prerecorded recordings
- feature-level dataset/group comparison
- NeuroMouse-compatible visualization outputs
- saved raw backend job logs for debugging and reproducibility

This project intentionally does **not** currently focus on:

- spike-event extraction as the primary data product
- stimulation start/stop alignment
- amplitude/frequency/location/block experimental labels
- assuming all files are 32-channel EEG

Those can be added later, but the current system is built around continuous neural dynamics.

---

## One-Command Launch

From the project folder, run:

```bash
python3 run_neuro_signal_app.py
```

The launcher script automatically:

1. Checks whether the local package is already installed from this folder.
2. Checks whether required Python libraries are importable.
3. Runs installation only if something is missing.
4. Starts the local FastAPI backend server.
5. Waits until the server health check passes.
6. Opens the browser.

By default, it opens the launcher app. Depending on launch options, it can also open NeuroMouse.

### Launcher options

```bash
python3 run_neuro_signal_app.py                 # normal install-check + launch
python3 run_neuro_signal_app.py --open app      # open only our launcher
python3 run_neuro_signal_app.py --open neuromouse
python3 run_neuro_signal_app.py --open both
python3 run_neuro_signal_app.py --no-browser    # start server only
python3 run_neuro_signal_app.py --force-install # intentionally reinstall
python3 run_neuro_signal_app.py --port 8790
python3 run_neuro_signal_app.py --workspace ~/neuro_signal_workspace
```

`--force-install` is not required for normal use. It is only for intentionally reinstalling.

---

## Manual Install, If Needed

The launcher usually handles this automatically, but the manual development install is:

```bash
pip install -e '.[all,frontend,live,dev]'
```

The package extras include:

```text
all       broad file-format support: MAT/HDF5/NWB/EDF/Excel/Zarr/etc.
frontend  FastAPI, Uvicorn, multipart upload support
live      ZeroMQ/WebSocket live replay backend
frontend  local HTML web app server dependencies
dev       pytest and development tools
```

---

## Supported Input Types

Archive uploads
  - .zip files containing primary neural files such as .mat, .edf, .set, .vhdr, .h5, .nwb, .npy, or .csv
  - archives are safely extracted into the upload workspace and then converted file-by-file


The importer can inspect/convert many neural signal sources, including:

```text
MATLAB .mat
  - .zip archives containing one or more MATLAB .mat datasets
  - DSamp-style files
  - EEGLAB-style structures
  - FieldTrip-style structures
  - generic MAT arrays with mapping support

HDF5-like files
  - generic HDF5
  - NWB-style HDF5
  - FinalSpark LiveMEA-style HDF5
  - Cortical Labs CL1-style HDF5
  - MaxWell/HD-MEA-style HDF5-like layouts

Standard neuro formats
  - EDF/BDF through optional MNE support
  - EEGLAB .set through MNE where available
  - NWB through optional PyNWB support

Simple array/table formats
  - .npy
  - .npz
  - .csv
  - .tsv
  - .xlsx
```


EEGLAB/BIDS sidecar note:

For EEGLAB/BIDS recordings, upload the primary signal/header file together with its sidecars. For example, upload `.set` with its matching `.fdt`, and upload BIDS files such as `*_channels.tsv`, `*_electrodes.tsv`, `*_events.tsv`, and `*_eeg.json` in the same folder. The backend now keeps these sidecars available for the reader, but it skips converting sidecars as standalone recordings so they do not cause false job failures.

For unknown MAT/HDF5 files, the system can generate a mapping template so the user can tell the importer which dataset is the signal, where channel names live, what the sampling rate is, and how units should be interpreted.

---

## Main Converted Output Format

A typical converted recording folder contains:

```text
converted_recording/
├── signal.npy              continuous signal, shape samples × channels
├── time.npy                optional time vector
├── channels.csv            channel/electrode names and metadata
├── electrodes.csv          electrode geometry if available
├── metadata.json           sampling rate, source info, units, etc.
├── quality_report.json     validation results and warnings
├── provenance.json         source paths, adapter used, hashes, config info
├── export_report.json      export choices and file sizes
├── qc_report.html          quick quality-control report
└── file_tree_report.json   HDF5-like structure report when applicable
```

The canonical rule is:

```text
signal.npy shape = samples × channels
```

Channel count and names are read from the data whenever possible. If names are missing, generated names are used:

```text
ch_000, ch_001, ch_002, ...
```

---

## Variable-Electrode Support

The system is no longer fixed to 32 channels. Channel count and channel names flow from the converted data.

The live and analysis pipeline supports:

```text
8, 16, 32, 64, 128, 256, 1024, or any other valid channel count
```

as long as the signal is a 2D continuous array:

```text
samples × channels
```

Channel metadata priority:

```text
1. channels.csv
2. metadata.json channel_manifest
3. source-file channel labels
4. selected channel profile
5. generated names ch_000, ch_001, ...
```

Included channel profiles include:

```text
generated_numeric
common EEG 10-10 32-channel profile
FinalSpark-style 32-electrode MEA profile
```

For FinalSpark-style 32-electrode MEA naming, the profile uses organoid/electrode-style labels such as:

```text
mea0_organoid0_e0
...
mea0_organoid3_e7
```

---

## Neuro Signal Launcher Frontend

Open:

```text
http://127.0.0.1:8787/
```

The launcher frontend supports:

- drag/drop file upload
- raw-file conversion
- path-based conversion for larger files/folders
- heartbeat progress from backend pipeline stages
- live replay setup
- NeuroMouse analysis setup
- group comparison setup
- quick HTML preview plots
- output-folder and report links

### Main launcher modes

```text
Import / Convert
  Convert raw files into canonical signal.npy + metadata outputs.

NeuroMouse
  Analyze current uploads in NeuroMouse, build data.json from converted folders,
  or launch live replay into NeuroMouse.

Live Replay
  Replay a converted recording like a live stream.

Compare
  Compare one dataset/group against another using feature-level summaries.

Results
  Open output folders, reports, generated data.json, NeuroMouse links, and raw job logs.

Raw Job Logs
  Every backend job now writes both a human-readable `job_log.txt` and a structured `job_log.jsonl`. These logs record pipeline events such as uploaded files, selected adapters, detected signal shapes, sampling-rate decisions, output paths, generated NeuroMouse dataset links, warnings, and errors. They do not dump raw neural samples.
```

---

## Original NeuroMouse Integration

The project includes the **original NeuroMouse workbench files** that were provided by the user.

They are stored in two places:

```text
neuro_signal_webapp/neuromouse/    served integrated copy

```

NeuroMouse is served at:

```text
http://127.0.0.1:8787/neuromouse/
```

The integrated NeuroMouse copy has minimal compatibility patches so it can:

- load backend-generated `data.json` through a query parameter
- distinguish demo data from backend-generated datasets
- show a visible backend-dataset banner only for real backend outputs
- accept variable channel counts instead of requiring 32 channels
- load NeuroMouse comparison manifests
- connect to NeuroMouse-compatible live replay WebSocket streams
- fall back to generic channel/electrode layouts when EEG 10-20/10-10 names are not available

---

## Analyze in NeuroMouse

This is the recommended workflow for interactive offline analysis.

In the launcher:

1. Drag/drop a raw neural file or files.
2. Choose options if needed.
3. Click **Analyze in NeuroMouse**.

The backend then:

```text
raw file/folder
    ↓
convert if needed
    ↓
load signal.npy + channels.csv + metadata.json
    ↓
compute offline NeuroMouse features
    ↓
write outputs/<job_id>/neuromouse/data.json
    ↓
open NeuroMouse with:
    /neuromouse/?dataset=/api/jobs/<job_id>/neuromouse/data.json&backend_job=<job_id>&backend=1
```

Important: NeuroMouse still plots a `data.json` file, because that is its native plotting format. The difference is that the `data.json` should now be **generated from your dragged/converted data**, not the bundled demo file.

### How to confirm it loaded your data

A correct backend-generated NeuroMouse page should show a source like:

```text
/api/jobs/<job_id>/neuromouse/data.json
```

It should not show:

```text
/neuromouse/data/data.json
```

If the source is `/neuromouse/data/data.json`, you are looking at the bundled NeuroMouse demo dataset, not the generated backend dataset.

Use the **Open generated NeuroMouse dataset** link in the launcher Results tab after analysis completes.

---

## NeuroMouse Data Output

The backend-generated NeuroMouse folder typically contains:

```text
neuromouse/
├── data.json
└── neuromouse_manifest.json
```

`data.json` includes NeuroMouse-compatible offline analysis arrays such as:

```text
meta
welch_psd
centroid
geometry
channel_summary
optional channel/group summaries
```

For large recordings, the backend samples/limits offline windows according to the NeuroMouse analysis options in the launcher. The original raw converted `signal.npy` is still preserved.

---

## Live Replay in NeuroMouse

Live replay is for prerecorded data streamed like a live source.

The data flow is:

```text
converted signal.npy
    ↓
variable-electrode live backend
    ↓
NeuroMouse-compatible WebSocket sample stream
    ↓
NeuroMouse live source view
```

The NeuroMouse live WebSocket endpoint uses metadata-driven frames:

```text
channel_names
n_channels
sampling_rate_hz
samples
```

This allows NeuroMouse to render data with any channel count, not only 32-channel EEG.

---

## Comparative Analysis

The system supports feature-level group comparison.

Use this when comparing:

```text
one dataset vs another dataset
one group of recordings vs another group
baseline vs treatment
trained vs untrained
subject/session A vs subject/session B
```

For comparisons, the backend can:

1. Convert raw files if needed.
2. Build NeuroMouse-compatible `data.json` files for each recording.
3. Compute feature-level summaries.
4. Build a comparison manifest.
5. Open NeuroMouse on the comparison.

This is safer than direct channel-to-channel comparison when datasets have different electrode counts or names.

### Same-channel vs feature-level comparison

Same-channel comparison is appropriate only when channel layouts match.

Feature-level comparison is appropriate when layouts differ, such as:

```text
32-channel EEG vs 64-channel EEG
FinalSpark 32-electrode MEA vs Cortical Labs 64-channel MEA
8-channel organoid recording vs 32-channel MEA recording
```

Feature-level comparison uses global/channel-distribution summaries instead of assuming channel `Fp1` equals `ch_000`, etc.

---

## CLI Quickstart

Inspect a file:

```bash
neuro-import inspect path/to/file.h5
```

Convert one file:

```bash
neuro-import convert path/to/file.h5 --output converted_recording
```

Batch convert a folder:

```bash
neuro-import batch raw_dataset/ --output converted_dataset/
```

Generate a mapping template for an unknown MAT/HDF5 file:

```bash
neuro-import generate-mapping weird_file.h5 --output mapping_help --sampling-rate 30000
```

Convert with a mapping file:

```bash
neuro-import convert weird_file.h5 --mapping mapping_help/mapping_template.yaml --output converted_weird
```

---

## Mapping YAML for Unknown Files

Example:

```yaml
signal_path: /recording/samples
sampling_rate: 30000
time_path: null
channel_names_path: /metadata/channel_names
orientation: auto
original_units: adc_counts
target_units: microvolts
scale_factor: 0.195
offset: 0
metadata:
  source_family: custom_hdf5
```

Use mapping files when the importer can open a file but cannot safely infer which array is the neural signal.

---

## Live Backend Commands

Run a complete variable-electrode live backend:

```bash
neuro-live-backend \
  --source converted_recording/signal.npy \
  --channels-csv converted_recording/channels.csv \
  --metadata-json converted_recording/metadata.json \
  --fs 1000 \
  --channel-profile auto
```

For FinalSpark-style 32-electrode MEA naming:

```bash
neuro-live-backend \
  --source converted_recording/signal.npy \
  --fs 30000 \
  --channel-profile finalspark_32
```

Individual components:

```bash
neuro-live-player --source signal.npy --fs 1000 --channel-profile generated_numeric
neuro-live-receiver
neuro-live-analyzer
```

Packaged standalone live HTML viewers:

```text
neuro_importer_live/raw_visualizer_variable.html
neuro_importer_live/spectral_visualizer_variable.html
```

---

## Backend API Summary

The local FastAPI server exposes endpoints used by the HTML launcher and NeuroMouse integration.

Important routes include:

```text
GET  /                                  launcher frontend
GET  /neuromouse/                       original NeuroMouse workbench
GET  /api/health                        server health/version/workspace
POST /api/jobs/convert-upload           convert uploaded files
POST /api/jobs/convert-paths            convert path-based files/folders
POST /api/jobs/inspect-upload           inspect uploaded files
POST /api/jobs/analyze-neuromouse-upload
POST /api/jobs/analyze-neuromouse-paths
POST /api/jobs/neuromouse-from-converted
POST /api/jobs/compare
POST /api/jobs/compare-neuromouse
GET  /api/jobs/<job_id>
GET  /api/jobs/<job_id>/raw-log.txt
GET  /api/jobs/<job_id>/raw-log.jsonl
GET  /api/jobs/<job_id>/raw-log
GET  /api/jobs/<job_id>/neuromouse/data.json
GET  /api/jobs/<job_id>/neuromouse/manifest.json
WS   /api/jobs/<job_id>/events          heartbeat progress events
WS   /ws/neuromouse/live                NeuroMouse-compatible live sample stream
GET  /api/file?path=...                 serve generated output file
GET  /api/open-output?path=...          ask OS to open output folder
```

---

## Output Folder Structure

By default, the app writes to a workspace like:

```text
~/neuro_signal_app_workspace/
├── uploads/
├── outputs/
│   └── <job_id>/
│       ├── converted/
│       ├── neuromouse/
│       │   ├── data.json
│       │   └── neuromouse_manifest.json
│       ├── comparison_manifest.json
│       ├── job_log.txt              human-readable raw backend job log
│       ├── job_log.jsonl            machine-readable structured event log
│       ├── qc_report.html
│       └── job/result files
└── logs/
```

The exact output folder is shown in the launcher Results tab after a job completes.

---

## Raw Backend Job Logs

Each job writes two saved logs into its output folder:

```text
job_log.txt    human-readable backend/pipeline log
job_log.jsonl  structured JSON-lines event log
```

These logs are intended for support, debugging, and reproducibility. They record the job id, job type, input paths, selected pipeline steps, progress events, adapter/conversion status, warnings, errors, output folders, and generated NeuroMouse dataset URLs. They are backend logs, not raw neural sample dumps.

In the launcher Results tab, use:

```text
View Raw Job Log
Download Raw Log
Download JSONL Log
```

The same files are also available through local routes:

```text
/api/jobs/<job_id>/raw-log.txt
/api/jobs/<job_id>/raw-log.jsonl
```

---

## Quality Control and Provenance

Each conversion stores quality/provenance files when possible:

```text
quality_report.json
provenance.json
export_report.json
qc_report.html
```

These include information such as:

- adapter used
- original source path
- detected signal shape
- detected or overridden sampling rate
- channel count
- unit conversion / scale factor
- warnings
- file hashes where available
- assumptions made during conversion

---

## Troubleshooting

### NeuroMouse / NeuroMouse still shows the demo data

The app now generates a NeuroMouse-compatible `data.json` after both **Convert** and **Analyze in NeuroMouse** jobs whenever possible. The generated page should open through a job-specific URL:

```text
/neuromouse-job/<job_id>/
```

That job page is hard-bound to:

```text
/api/jobs/<job_id>/neuromouse/data.json
```

It should not silently fall back to the bundled demo file:

```text
/neuromouse/data/data.json
```

If you still see the demo source, first make sure the old server is stopped and the new package was installed from the real app folder:

```bash
pkill -f neuro_signal_webapp.app_server
cd /home/a/projects/Complete-Neural-Signal-Analysis/GUI/neuro_signal_importer_analyzer
python3 run_neuro_signal_app.py --force-install
```

Then rerun the job and open the **Open generated NeuroMouse dataset from this job** link in the Results tab. You can intentionally open the bundled demo with:

```text
/neuromouse/?demo=1
```

### Browser did not open automatically

Open manually:

```text
http://127.0.0.1:8787/
```

or:

```text
http://127.0.0.1:8787/neuromouse/
```

### Port already in use

Use another port:

```bash
python3 run_neuro_signal_app.py --port 8790
```

### Install check did not pick up new code

Force reinstall intentionally:

```bash
python3 run_neuro_signal_app.py --force-install
```

### Large files are slow in browser upload

For very large files/folders, prefer path-based conversion or CLI conversion rather than browser upload. Browser drag/drop may copy data into the local workspace first.

### Unknown MAT/HDF5 file cannot convert

Generate a mapping template:

```bash
neuro-import generate-mapping weird_file.h5 --output mapping_help --sampling-rate 30000
```

Then edit the YAML and rerun conversion with `--mapping`.

---

## Project Layout

```text
neuro_importer/
  conversion backend, adapters, readers, validators, exporters

neuro_importer_live/
  variable-electrode live player, receiver, analyzer, WebSocket bridges, live HTML viewers

neuro_importer_analysis/
  offline feature extraction and comparative analysis

neuro_importer_neuromouse/
  NeuroMouse-compatible data.json builder, comparison packager, live bridge

neuro_signal_webapp/
  local FastAPI app, launcher frontend, integrated served NeuroMouse copy

neuro_signal_webapp/static/
  our HTML launcher frontend

neuro_signal_webapp/neuromouse/
  custom integrated NeuroMouse workbench with backend-loading, variable-electrode, live replay, and advanced-plot compatibility patches

run_neuro_signal_app.py
  install-check, server startup, browser launcher
```

---

## Testing

Run tests with:

```bash
pytest
```

The test suite covers:

- synthetic DSamp MAT conversion
- next-generation adapters
- HDF5 continuous adapters
- batch/QC/window features
- mapping/unit/large-file exports
- heartbeat progress events
- HTML/FastAPI app routes
- variable-electrode live backend
- NeuroMouse integration routes
- progress-event regression handling

---

## Recommended User Workflow

For a normal user:

```text
1. Run: python3 run_neuro_signal_app.py
2. Browser opens at http://127.0.0.1:8787/
3. Drag/drop raw neural file(s).
4. Click Analyze in NeuroMouse.
5. Wait for heartbeat progress to finish.
6. Use the generated NeuroMouse dataset link in Results.
7. Explore the data in NeuroMouse.
```

For development/CLI:

```text
1. Convert raw files with neuro-import.
2. Inspect converted signal.npy / channels.csv / metadata.json.
3. Build NeuroMouse data.json through the launcher or backend API.
4. Run live replay or comparison as needed.
```

---

## Current Status

This is the first complete integrated version where:

```text
raw neural files/folders
    → canonical conversion
    → variable-electrode metadata
    → offline NeuroMouse-compatible analysis
    → integrated original NeuroMouse visualization
    → optional live replay
    → optional group comparison
```

The system is still under active development, but the architecture is now set up so our backend can feed the original NeuroMouse workbench while preserving our own HTML launcher/frontend and variable-electrode neuro-signal pipeline.


## v0.9.7 Sidecar Upload Fix

This update makes browser multi-file uploads treat EEGLAB `.fdt`, BrainVision `.eeg`/`.vmrk`, and BIDS TSV/JSON files as sidecars only. They are copied into the upload folder so the primary `.set` or `.vhdr` file can read them, but they are not converted as standalone recordings. This fixes failures where `sub-001_task-Rest_eeg.fdt` was incorrectly sent to the converter by itself.


## v0.9.8 Sidecar Filtering and Explicit Raw Logs

This release makes sidecar handling stricter and the raw job logs more explicit.

- `.fdt`, `.eeg`, `.vmrk`, BIDS JSON/TSV sidecars, and other non-primary files are copied for traceability but are not converted as standalone recordings.
- If a `.fdt` sidecar is passed directly and a matching `.set` header exists beside it, the job manager promotes the `.set` file and logs that decision.
- Conversion and NeuroMouse analysis logs now include app version, requested paths, primary files selected for conversion, skipped sidecars, and promoted sidecar-to-primary matches.
- The launcher now refuses to silently reuse an older server running on the same port when its `/api/health` version does not match the launcher version.

For EEGLAB/BIDS uploads, upload the `.set` and `.fdt` together, but the raw log should show only the `.set` under `primary_files`. The `.fdt` should appear under `skipped` or `promoted`, not under `Converting ...`.


### v0.11.0 Advanced NeuroMouse Plot Generation

Backend-generated NeuroMouse datasets now include the same major analysis objects used by the original NeuroMouse demo views: Welch PSD heatmaps, spectral geometry, polar alpha chronomap, Kuramoto phase animation, channel network / PLV synchrony, Higuchi fractal-dimension traces, area-normalized PSD, and a lightweight TDA persistence view. These objects are generated from the uploaded/converted `signal.npy`, not from the bundled demo `data.json`.


## v0.11.0 visualization stability fix

This release restores the core NeuroMouse plotting path and makes the browser workbench crash-resistant. Backend-generated NeuroMouse datasets still include the original plot families, but the browser now validates and normalizes generated data before drawing. If one optional advanced view cannot render, the PSD heatmap, centroid, geometry stack, channel grid, playback, and other working views remain available instead of the entire page failing.

## v0.11.0 NeuroMouse frontend visualization restore

This patch fixes a browser-side NeuroMouse data normalization bug introduced in the visualization-stability layer. The bug truncated frequency and time arrays to one value before rendering, which could make the NeuroMouse buttons appear inactive and leave the PSD, centroid, geometry, playback, and advanced visualization panels blank. v0.11.0 preserves the full generated `data.json` arrays, keeps the v0.11.0 advanced analysis outputs, and keeps per-view error isolation so one optional advanced view cannot break the whole workbench.


## v0.11.0 NeuroMouse frontend rollback/stability fix

This release restores the known-good NeuroMouse browser frontend path and removes the browser-side normalization layer that could stop buttons and plots from initializing. The backend can still generate richer NeuroMouse `data.json` files from converted recordings, but the browser now receives them through the stable loader/plotting code. The bundled demo `data/data.json` is restored to the original NeuroMouse reference dataset so generated backend datasets cannot look identical to an accidentally-overwritten demo file.

The local FastAPI server now sends no-cache headers for launcher and NeuroMouse assets, and the HTML entry points use updated cache-busting query strings. After installing this version, restart the server and hard-refresh once if the browser was open during an older version.


## v0.11.0 NeuroMouse blank-page/button recovery fix

This patch changes the NeuroMouse browser startup so controls are bound before plotting modules initialize. Each visualization panel is now isolated: if PSD, centroid, geometry, channel grid, Kuramoto, network, TDA, or another optional view throws a browser-side error, the rest of the NeuroMouse workbench continues to load and that panel shows a visible error message instead of blanking the whole page. The patch also cache-busts the NeuroMouse JavaScript and CSS so stale broken frontend files are not reused after updating.

## v0.11.0 NeuroMouse persisted-job data endpoint fix

This patch fixes a NeuroMouse startup error where a generated dataset URL such as
`/api/jobs/<job_id>/neuromouse/data.json` could return HTTP 404 after the local
server restarted or after the in-memory job table was cleared. The API now
recovers generated NeuroMouse `data.json` files from the saved workspace output
folder, including `outputs/<job_id>/neuromouse/*/data.json` and legacy
`speedmouse` folder names. This keeps browser history, Results-tab links, and
job-specific NeuroMouse pages usable as long as the job output folder still
exists on disk.


## v0.11.0 NeuroMouse latest-dataset 404 recovery

This patch fixes NeuroMouse startup errors where an older browser-stored job URL could request `/api/jobs/<old_job_id>/neuromouse/data.json` and return HTTP 404 even after a newer conversion produced valid NeuroMouse output. The launcher now asks the backend for the newest generated NeuroMouse dataset before trusting local browser storage, plain `/neuromouse/` prefers the newest backend dataset, `/neuromouse-latest/` hard-binds NeuroMouse to the newest generated output, and old job-specific data endpoints fall back to the newest generated dataset instead of blanking the NeuroMouse page when a stale job id is requested.


## v0.11.0 update

The app now carries only the custom integrated NeuroMouse workbench under `neuro_signal_webapp/neuromouse/`. The old `vendor/neuromouse_original/` reference copy was removed because the upstream NeuroMouse repository is expected to change regularly. The integrated copy remains local so the Neuro Signal backend can reliably load generated datasets, archive conversions, live replay streams, and variable-electrode advanced visualizations.
